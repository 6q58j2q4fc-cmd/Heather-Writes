/*
 * DR. HEATHER ALLANSDOTTIR — AUTHOR WEBSITE
 * Design: Blossom-style Botanical — coral / golden yellow / teal / cream
 * Layout: Hero → About → Fiction → Non-Fiction → Speaker Bookings → Writing Workshops → Contact → Footer
 * Typography: Dancing Script (display) + Cormorant Garamond (serif) + Raleway (sans)
 * Improvements: 3D book covers, streamlined flow, no redundant images, bolder readable text
 */

import { useEffect, useState } from "react";

// ── CDN URLs ─────────────────────────────────────────────────────────────────
const HERO_BOOKS        = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/hero-books-7xNzZuPgJgovoxMm9YvpQA.webp";
const FLORAL_BORDER     = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/floral-border-aRBBZnhWeGcLTZv2qVrfdt.webp";
const FLORAL_PANEL      = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/floral-side-panel-D7PGzwNn7VgzvnM3Qmwqte.webp";
const AUTHOR_PHOTO      = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/heather-real-photo_297ebcba.jpg";

// 3D book covers
const PSALM119_3D       = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/psalm119-real-final_8079ad17.png";
const PORT_AUTH_3D      = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/port-authority-3d-nkepnT96x5uiMLmW9aAod8.webp";
const BUDAPEST_3D       = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/budapest-3d-FgzwDhJhsjZN2cBADZxJXq.webp";
const SAGA_3D           = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/saga-3d-4pNyPBPqzJioxuZan7uUjt.webp";
const LIT_FREE_3D       = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/literary-freedom-3d-HfsjDvCLciZuQfwvqPjVhi.webp";
const SPACE_LAW_3D      = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/space-law-coming-soon-3d-bwmYJ9KytqSaHBytNEKoTX.webp";
const CASE_SPACE_3D     = "https://d2xsxph8kpxj0f.cloudfront.net/310519663234433834/DqJCePE7vNoLcJwJqQL8pG/case-for-space-coming-soon-3d-SYzoSHsUVaassxbegtSfbx.webp";

// ── Autumnal Palette (meancreative.com) ──────────────────────────────────────
// #F2C186 pale amber · #D97803 amber gold · #A63922 rust red · #723A19 brown · #3F271D dark chocolate
const CORAL   = "#A63922";   // burnt sienna / rust red  — was coral
const GOLDEN  = "#D97803";   // warm amber gold           — was golden
const TEAL    = "#723A19";   // deep warm brown           — was teal
const CREAM   = "#fdf5ea";   // warm parchment cream      — was cream
const DARK    = "#3F271D";   // dark chocolate            — was dark

// ── Nav tabs ─────────────────────────────────────────────────────────────────
const TABS = [
  { id: "about",      label: "About" },
  { id: "fiction",    label: "Fiction" },
  { id: "nonfiction", label: "Non-Fiction" },
  { id: "speaker",    label: "Speaker Bookings" },
  { id: "workshops",  label: "Writing Workshops" },
];

// ── Helpers ──────────────────────────────────────────────────────────────────
function FloralDivider({ flip = false }: { flip?: boolean }) {
  return (
    <div className="w-full overflow-hidden" style={{ height: 80, transform: flip ? "scaleY(-1)" : undefined }}>
      <img src={FLORAL_BORDER} alt="" aria-hidden className="w-full h-full object-cover" />
    </div>
  );
}

// ── 3D Book card ──────────────────────────────────────────────────────────────
function BookCard3D({
  cover, title, author, publisher, buyUrl, comingSoon = false, bg = TEAL,
}: {
  cover?: string; title: string; author?: string; publisher?: string;
  buyUrl?: string; comingSoon?: boolean; bg?: string;
}) {
  return (
    <div className="flex flex-col items-center text-center" style={{ width: 180 }}>
      {/* Book image with 3D hover effect */}
      <div className="relative w-full group" style={{ perspective: 800 }}>
        <div
          className="relative overflow-hidden transition-transform duration-500 group-hover:scale-[1.04]"
          style={{
            aspectRatio: "2/3",
            borderRadius: 4,
            boxShadow: "6px 12px 30px rgba(0,0,0,0.28), 2px 4px 8px rgba(0,0,0,0.15)",
          }}
        >
          {cover ? (
            <img src={cover} alt={title} className="w-full h-full object-cover" />
          ) : (
            <div
              className="w-full h-full flex items-center justify-center p-4 text-center"
              style={{
                background: `linear-gradient(145deg, ${bg}, ${bg}bb)`,
                fontFamily: "'Cormorant Garamond', serif",
                color: "#fff",
                fontSize: "1.1rem",
                fontStyle: "italic",
                lineHeight: 1.5,
                fontWeight: 600,
              }}
            >
              {title}
            </div>
          )}
          {/* Coming Soon ribbon */}
          {comingSoon && (
            <div
              className="absolute top-[30px] left-[-38px] w-[180px] text-center py-[6px]"
              style={{
                background: CORAL,
                color: "#fff",
                fontSize: "0.6rem",
                fontWeight: 800,
                letterSpacing: "0.16em",
                textTransform: "uppercase",
                transform: "rotate(-45deg)",
                transformOrigin: "center",
                boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
              }}
            >
              Coming Soon
            </div>
          )}
        </div>
      </div>

      {/* Book info */}
      <div className="pt-4 w-full">
        <p
          className="font-bold leading-snug mb-1"
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            color: "#fff",
            fontSize: "1rem",
            textShadow: "0 1px 3px rgba(0,0,0,0.3)",
          }}
        >
          {title}
        </p>
        {author && (
          <p className="mb-1 font-semibold" style={{ fontSize: "0.82rem", color: "rgba(255,255,255,0.85)" }}>
            {author}
          </p>
        )}
        {publisher && (
          <p className="mb-2 font-semibold" style={{ fontSize: "0.78rem", color: "rgba(255,255,255,0.75)" }}>
            {publisher}
          </p>
        )}
        {buyUrl && (
          <a
            href={buyUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block font-bold tracking-widest uppercase transition-all hover:-translate-y-0.5 hover:shadow-md"
            style={{ background: CORAL, color: "#fff", fontSize: "0.8rem", padding: "8px 18px", borderRadius: 4, letterSpacing: "0.14em", fontWeight: 900 }}>
            Buy on Amazon
          </a>
        )}
      </div>
    </div>
  );
}

// ── Form helpers ─────────────────────────────────────────────────────────────
function Field({ label, id, type = "text", placeholder, required = false }: {
  label: string; id: string; type?: string; placeholder?: string; required?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="font-bold tracking-widest uppercase" style={{ fontSize: "0.7rem", color: CORAL }}>
        {label}
      </label>
      <input
        id={id} name={id} type={type} placeholder={placeholder} required={required}
        className="border px-4 py-3 outline-none transition-colors font-medium"
        style={{ borderColor: "#d4c4a8", borderRadius: 4, background: "#fff", color: DARK, fontSize: "0.9rem" }}
        onFocus={e => (e.currentTarget.style.borderColor = CORAL)}
        onBlur={e => (e.currentTarget.style.borderColor = "#d4c4a8")}
      />
    </div>
  );
}

function Textarea({ label, id, placeholder, rows = 4, required = false }: {
  label: string; id: string; placeholder?: string; rows?: number; required?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="font-bold tracking-widest uppercase" style={{ fontSize: "0.7rem", color: CORAL }}>
        {label}
      </label>
      <textarea
        id={id} name={id} placeholder={placeholder} rows={rows} required={required}
        className="border px-4 py-3 outline-none transition-colors resize-none font-medium"
        style={{ borderColor: "#d4c4a8", borderRadius: 4, background: "#fff", color: DARK, fontSize: "0.9rem" }}
        onFocus={e => (e.currentTarget.style.borderColor = CORAL)}
        onBlur={e => (e.currentTarget.style.borderColor = "#d4c4a8")}
      />
    </div>
  );
}

// ── SECTION: Hero ─────────────────────────────────────────────────────────────
function HeroSection() {
  return (
    <section id="hero" className="w-full">
      {/* Full-width hero — no pastel books photo */}
      <div
        className="w-full flex flex-col justify-center items-start px-8 md:px-20 py-20 relative overflow-hidden"
        style={{ background: CORAL, minHeight: "clamp(320px, 44vw, 520px)" }}
      >
        {/* Subtle floral watermark */}
        <img src={FLORAL_PANEL} alt="" aria-hidden
          className="absolute inset-0 w-full h-full object-cover opacity-10 pointer-events-none" />
        <div className="relative z-10 max-w-2xl">
          <p className="font-bold tracking-widest uppercase mb-4" style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.85)" }}>
            Award-Winning Author &amp; Academic
          </p>
          <h1
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: "#fff",
              fontSize: "clamp(3rem, 7vw, 5.2rem)",
              lineHeight: 1.05,
              textShadow: "0 2px 16px rgba(0,0,0,0.18)",
            }}
            className="mb-4"
          >
            Heather Allansdottir writes
          </h1>
          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: "rgba(255,255,255,0.92)",
              fontSize: "1.2rem",
              lineHeight: 1.8,
              maxWidth: 520,
              fontWeight: 600,
            }}
            className="mb-8"
          >
            Fiction, non-fiction, scholarly and popular works — across genres and disciplines.
          </p>
          <div className="flex gap-3 flex-wrap">
            <a
              href="#fiction"
              className="inline-flex items-center gap-2 font-bold tracking-widest uppercase px-6 py-3 transition-all hover:-translate-y-0.5 hover:shadow-lg"
              style={{ background: GOLDEN, color: DARK, borderRadius: 4, fontSize: "0.88rem", fontWeight: 900 }}
            >
              Explore Books
            </a>
            <a
              href="#speaker"
              className="inline-flex items-center gap-2 font-bold tracking-widest uppercase px-6 py-3 border-2 transition-all hover:bg-white/15"
              style={{ color: "#fff", borderColor: "#fff", borderRadius: 4, fontSize: "0.88rem", fontWeight: 900, background: "rgba(255,255,255,0.25)", textShadow: "0 1px 3px rgba(0,0,0,0.2)" }}
            >
              Book a Talk
            </a>
          </div>
        </div>
      </div>
      <FloralDivider />
    </section>
  );
}

// ── SECTION: About ────────────────────────────────────────────────────────────
function AboutSection() {
  return (
    <section id="about" className="w-full scroll-mt-16">
      <div className="flex flex-col md:flex-row" style={{ minHeight: "clamp(360px, 46vw, 520px)" }}>
        {/* Left: floral botanical strip */}
        <div className="hidden md:block flex-shrink-0 w-52 overflow-hidden">
          <img src={FLORAL_PANEL} alt="" aria-hidden className="w-full h-full object-cover" />
        </div>
        {/* Centre: golden text panel */}
        <div
          className="flex-1 flex flex-col justify-center px-8 md:px-12 py-10"
          style={{ background: GOLDEN }}
        >
          <p className="font-bold tracking-widest uppercase mb-2" style={{ fontSize: "0.7rem", color: `${DARK}99` }}>
            Hello, reader!
          </p>
          <h2
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: DARK,
              fontSize: "clamp(2.4rem, 5vw, 3.6rem)",
              lineHeight: 1.1,
            }}
            className="mb-5"
          >
            I'm Heather
          </h2>
          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: DARK,
              fontSize: "1.15rem",
              lineHeight: 1.8,
              maxWidth: 500,
              fontWeight: 600,
            }}
            className="mb-4"
          >
            Dr. Heather Allansdottir is an award-winning writer and academic. She writes
            fiction and non-fiction, scholarly and popular works. She has written widely for
            the UK and international media and is available for speaking engagements.
          </p>
          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: DARK,
              fontSize: "1.05rem",
              lineHeight: 1.8,
              maxWidth: 500,
              fontWeight: 600,
            }}
            className="mb-7"
          >
            Her writing workshops for literary fiction, thrillers and dark academia are
            coming soon. Find out more about her work here!
          </p>
          <div className="flex flex-wrap gap-3 items-center">
            <a
              href="https://allofallansdottir.substack.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block font-bold tracking-widest uppercase px-6 py-3 transition-all hover:-translate-y-0.5 hover:shadow-md"
              style={{ background: TEAL, color: "#fff", borderRadius: 4, fontSize: "0.88rem", fontWeight: 900, letterSpacing: "0.1em" }}
            >
              Follow on Substack
            </a>
            <a
              href="#fiction"
              className="inline-block font-bold tracking-widest uppercase px-6 py-3 transition-all hover:-translate-y-0.5 hover:shadow-md"
              style={{ background: CORAL, color: "#fff", borderRadius: 4, fontSize: "0.88rem", fontWeight: 900 }}
            >
              View My Books
            </a>
          </div>
        </div>
        {/* Right: author photo */}
        <div className="flex-shrink-0 w-full md:w-[36%] overflow-hidden" style={{ minHeight: 340 }}>
          <img
            src={AUTHOR_PHOTO}
            alt="Dr. Heather Allansdottir"
            className="w-full h-full object-cover object-top"
            style={{ filter: "contrast(1.04) saturate(1.06)" }}
          />
        </div>
      </div>
      <FloralDivider />
    </section>
  );
}

// ── SECTION: Fiction Books ────────────────────────────────────────────────────
function FictionSection() {
  return (
    <section id="fiction" className="w-full scroll-mt-16 py-16" style={{ background: "#8B2E2E" }}>
      <div className="container">
        {/* Section heading */}
        <div className="text-center mb-12">
          <p className="font-bold tracking-widest uppercase mb-2" style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.7)" }}>
            Published Works
          </p>
          <h2
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: "#fff",
              fontSize: "clamp(2.4rem, 5vw, 3.4rem)",
              textShadow: "0 2px 8px rgba(0,0,0,0.15)",
            }}
          >
            Fiction
          </h2>
        </div>

        {/* Published: Psalm 119 */}
        <div className="flex justify-center mb-14">
          <BookCard3D
            cover={PSALM119_3D}
            title="Psalm 119"
            author="Heather McRobie"
            buyUrl="https://www.amazon.com/stores/Heather-McRobie/author/B002662RVQ?ref=ap_rdr&shoppingPortalEnabled=true"
          />
        </div>

        {/* Divider: Coming Soon */}
        <div className="flex items-center gap-4 mb-12 max-w-2xl mx-auto">
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.25)" }} />
          <h3
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: GOLDEN,
              fontSize: "clamp(1.8rem, 4vw, 2.6rem)",
              whiteSpace: "nowrap",
            }}
          >
            Coming Soon!
          </h3>
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.25)" }} />
        </div>

        {/* Coming soon: 3 books */}
        <div className="flex flex-wrap justify-center gap-10 lg:gap-14">
          <BookCard3D cover={PORT_AUTH_3D}  title="Port Authority"         author="Heather Allansdottir" comingSoon />
          <BookCard3D cover={BUDAPEST_3D}   title="The Budapest Questions" author="Heather Allansdottir" comingSoon />
          <BookCard3D cover={SAGA_3D}       title="A Bit Of A Saga"        author="Heather Allansdottir" comingSoon />
        </div>
      </div>
      <div className="mt-14">
        <FloralDivider />
      </div>
    </section>
  );
}

// ── SECTION: Non-Fiction Books ────────────────────────────────────────────────
function NonFictionSection() {
  return (
    <section id="nonfiction" className="w-full scroll-mt-16 py-16" style={{ background: "#B8860B" }}>
      <div className="container">
        <div className="text-center mb-12">
          <p className="font-bold tracking-widest uppercase mb-2" style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.7)" }}>
            Published Works
          </p>
          <h2
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: "#fff",
              fontSize: "clamp(2.4rem, 5vw, 3.4rem)",
              textShadow: "0 2px 8px rgba(0,0,0,0.15)",
            }}
          >
            Non-Fiction
          </h2>
        </div>

        {/* Published: Literary Freedom */}
        <div className="flex justify-center mb-14">
          <BookCard3D
            cover={LIT_FREE_3D}
            title="Literary Freedom"
            author="Heather McRobie (2013)"
            buyUrl="https://www.amazon.co.uk/Literary-Freedom-Literature-Katherine-2013-12-07/dp/B01FGO56VM"
          />
        </div>

        {/* Coming Soon divider */}
        <div className="flex items-center gap-4 mb-12 max-w-2xl mx-auto">
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.25)" }} />
          <h3
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: GOLDEN,
              fontSize: "clamp(1.8rem, 4vw, 2.6rem)",
              whiteSpace: "nowrap",
            }}
          >
            Coming Soon!
          </h3>
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.25)" }} />
        </div>

        {/* Coming soon: 2 space books */}
        <div className="flex flex-wrap justify-center gap-10 lg:gap-14">
          <BookCard3D
            cover={SPACE_LAW_3D}
            title="New Perspectives in Outer Space Law"
            publisher="Springer, 2026"
            comingSoon
          />
          <BookCard3D
            cover={CASE_SPACE_3D}
            title="The Case for Space"
            publisher="2027"
            comingSoon
          />
        </div>
      </div>
      <div className="mt-14">
        <FloralDivider />
      </div>
    </section>
  );
}

// ── SECTION: Mailing List ─────────────────────────────────────────────────────
function MailingListSection() {
  const [submitted, setSubmitted] = useState(false);
  return (
    <section className="w-full py-14 text-center" style={{ background: CORAL }}>
      <div className="container max-w-xl">
        {submitted ? (
          <p style={{ fontFamily: "'Dancing Script', cursive", color: "#fff", fontSize: "2.2rem" }}>
            Thank you for subscribing!
          </p>
        ) : (
          <>
            <h2
              style={{
                fontFamily: "'Dancing Script', cursive",
                color: "#fff",
                fontSize: "clamp(2rem, 5vw, 3.2rem)",
                textShadow: "0 2px 8px rgba(0,0,0,0.12)",
              }}
              className="mb-2"
            >
              Join the mailing list!
            </h2>
            <p
              className="mb-7 font-semibold"
              style={{ fontFamily: "'Cormorant Garamond', serif", color: "#fff", fontSize: "1.1rem", lineHeight: 1.7 }}
            >
              Be the first to know about new releases, events, and more.
            </p>
            <form
              onSubmit={e => { e.preventDefault(); setSubmitted(true); }}
              className="flex flex-col sm:flex-row gap-3 justify-center"
            >
              <input
                type="email"
                placeholder="Your email address"
                required
                className="flex-1 px-4 py-3 font-medium outline-none"
                style={{ borderRadius: 4, border: "none", color: DARK, fontSize: "0.9rem", maxWidth: 340 }}
              />
              <button
                type="submit"
                className="font-bold tracking-widest uppercase px-6 py-3 transition-all hover:-translate-y-0.5 hover:shadow-md"
                style={{ background: GOLDEN, color: DARK, borderRadius: 4, border: "none", fontSize: "0.88rem", fontWeight: 900 }}
              >
                Subscribe &amp; Save
              </button>
            </form>
          </>
        )}
      </div>
    </section>
  );
}

// ── SECTION: Speaker Bookings ─────────────────────────────────────────────────
function SpeakerSection() {
  const [submitted, setSubmitted] = useState(false);
  return (
    <section id="speaker" className="w-full scroll-mt-16 py-16" style={{ background: CREAM }}>
      <FloralDivider flip />
      <div className="container py-6">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16 items-start">
          {/* Left: author photo */}
          <div
            className="flex-shrink-0 w-full lg:w-72 overflow-hidden shadow-xl"
            style={{ borderRadius: 8 }}
          >
            <img
              src={AUTHOR_PHOTO}
              alt="Dr. Heather Allansdottir"
              className="w-full object-cover object-top"
              style={{ maxHeight: 400 }}
            />
          </div>
          {/* Right: form */}
          <div className="flex-1 max-w-xl">
            <p className="font-bold tracking-widest uppercase mb-2" style={{ fontSize: "0.72rem", color: CORAL }}>
              Speaker Bookings
            </p>
            <h2
              style={{
                fontFamily: "'Dancing Script', cursive",
                color: CORAL,
                fontSize: "clamp(2.2rem, 5vw, 3.4rem)",
                lineHeight: 1.1,
              }}
              className="mb-5"
            >
              Book Heather to Speak
            </h2>
            <p
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                color: DARK,
                fontSize: "1.15rem",
                lineHeight: 1.8,
                fontWeight: 600,
              }}
              className="mb-7"
            >
              Dr. Heather Allansdottir is available for speaking engagements on topics spanning
              literary fiction, academic freedom, international law, outer space law, and the
              intersection of culture and politics.
            </p>
            {submitted ? (
              <p style={{ fontFamily: "'Dancing Script', cursive", color: CORAL, fontSize: "1.8rem" }}>
                Thank you — your enquiry has been received!
              </p>
            ) : (
              <form
                onSubmit={e => { e.preventDefault(); setSubmitted(true); }}
                className="flex flex-col gap-4"
              >
                <Field label="Your Name"     id="s-name"  placeholder="Full name"             required />
                <Field label="Email Address" id="s-email" type="email" placeholder="your@email.com" required />
                <Field label="Organisation"  id="s-org"   placeholder="Organisation or event name" />
                <Field label="Proposed Date" id="s-date"  placeholder="e.g. October 2026" />
                <Textarea label="Topic / Brief" id="s-topic" placeholder="Please describe the event and topic…" required />
                <div>
                  <button
                    type="submit"
                    className="font-bold tracking-widest uppercase px-8 py-3 transition-all hover:-translate-y-0.5 hover:shadow-md"
                    style={{ background: CORAL, color: "#fff", borderRadius: 4, fontSize: "0.88rem", fontWeight: 900 }}
                  >
                    Send Enquiry
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

// ── SECTION: Writing Workshops ────────────────────────────────────────────────
function WorkshopsSection() {
  const [submitted, setSubmitted] = useState(false);
  return (
    <section id="workshops" className="w-full scroll-mt-16 py-16" style={{ background: CREAM }}>
      <div className="container">
        {/* Banner */}
        <div
          className="w-full text-center px-8 py-12 mb-12 relative overflow-hidden"
          style={{ background: "#5c3d28", borderRadius: 10 }}
        >
          <img src={FLORAL_BORDER} alt="" aria-hidden
            className="absolute bottom-0 left-0 w-full h-14 object-cover opacity-30 pointer-events-none" />
          <p className="font-bold tracking-widest uppercase mb-2" style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.75)" }}>
            Coming Soon — 2026
          </p>
          <h2
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: "#fff",
              fontSize: "clamp(2.4rem, 5vw, 3.4rem)",
              textShadow: "0 2px 8px rgba(0,0,0,0.15)",
            }}
            className="mb-4"
          >
            Writing Workshops
          </h2>
          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: "#fff",
              fontSize: "1.15rem",
              lineHeight: 1.8,
              maxWidth: 580,
              margin: "0 auto",
              fontWeight: 600,
            }}
          >
            Workshops for literary fiction, thrillers, and dark academia — launching 2026.
            Register your interest to be first to hear when places open.
          </p>
        </div>

        <div className="max-w-xl mx-auto">
          <h3
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: DARK,
              fontSize: "clamp(1.8rem, 4vw, 2.6rem)",
            }}
            className="mb-7 text-center"
          >
            Register Your Interest
          </h3>
          {submitted ? (
            <p className="text-center" style={{ fontFamily: "'Dancing Script', cursive", color: CORAL, fontSize: "1.8rem" }}>
              Thank you! We'll be in touch when workshops open.
            </p>
          ) : (
            <form
              onSubmit={e => { e.preventDefault(); setSubmitted(true); }}
              className="flex flex-col gap-4"
            >
              <Field label="Your Name"     id="w-name"  placeholder="Full name"        required />
              <Field label="Email Address" id="w-email" type="email" placeholder="your@email.com" required />
              <div className="flex flex-col gap-1.5">
                <label htmlFor="w-interest" className="font-bold tracking-widest uppercase" style={{ fontSize: "0.7rem", color: CORAL }}>
                  Workshop Interest
                </label>
                <select
                  id="w-interest"
                  name="w-interest"
                  className="border px-4 py-3 outline-none font-medium"
                  style={{ borderColor: "#d4c4a8", borderRadius: 4, background: "#fff", color: DARK, fontSize: "0.9rem" }}
                >
                  <option value="all">Select a workshop type…</option>
                  <option value="literary-fiction">Literary Fiction</option>
                  <option value="thrillers">Thrillers</option>
                  <option value="dark-academia">Dark Academia</option>
                  <option value="not-sure">All / Not Sure Yet</option>
                </select>
              </div>
              <Textarea label="Anything else?" id="w-message" placeholder="Optional…" rows={3} />
              <div>
                <button
                  type="submit"
                  className="font-bold tracking-widest uppercase px-8 py-3 transition-all hover:-translate-y-0.5 hover:shadow-md"
style={{ background: GOLDEN, color: DARK, borderRadius: 4, fontSize: "0.88rem", fontWeight: 900 }}
                  >
                    Register Interest
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

// ── SECTION: Contact ──────────────────────────────────────────────────────────
function ContactSection() {
  const [submitted, setSubmitted] = useState(false);
  return (
    <section id="contact" className="w-full scroll-mt-16">
      <FloralDivider />
      <div className="flex flex-col md:flex-row" style={{ minHeight: 400 }}>
        {/* Left: author photo */}
        <div className="flex-shrink-0 w-full md:w-[42%] overflow-hidden" style={{ minHeight: 320 }}>
          <img
            src={AUTHOR_PHOTO}
            alt="Dr. Heather Allansdottir"
            className="w-full h-full object-cover object-top"
          />
        </div>
        {/* Right: coral contact panel */}
        <div
          className="flex-1 flex flex-col justify-center px-8 md:px-12 py-12"
          style={{ background: CORAL }}
        >
          <h2
            style={{
              fontFamily: "'Dancing Script', cursive",
              color: "#fff",
              fontSize: "clamp(2.2rem, 5vw, 3.2rem)",
              textShadow: "0 2px 8px rgba(0,0,0,0.12)",
            }}
            className="mb-2"
          >
            Get in Touch!
          </h2>
          <p
            className="mb-6 font-semibold"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#fff", fontSize: "1.1rem", lineHeight: 1.75 }}
          >
            For speaking enquiries, press, or general questions — get in touch.
          </p>
          <div className="flex flex-col gap-2 mb-6">
            <a
              href="https://allofallansdottir.substack.com"
              target="_blank"
              rel="noopener noreferrer"
              className="font-bold text-white hover:text-white/80 transition-colors"
              style={{ fontSize: "0.95rem" }}
            >
              ✉ allofallansdottir.substack.com
            </a>
          </div>
          {submitted ? (
            <p style={{ fontFamily: "'Dancing Script', cursive", color: "#fff", fontSize: "1.8rem" }}>
              Message sent — thank you!
            </p>
          ) : (
            <form
              onSubmit={e => { e.preventDefault(); setSubmitted(true); }}
              className="flex flex-col gap-3"
            >
              <input
                type="text"
                placeholder="Your name"
                required
                className="px-4 py-3 font-medium outline-none"
                style={{ borderRadius: 4, border: "none", color: DARK, fontSize: "0.9rem" }}
              />
              <input
                type="email"
                placeholder="Your email"
                required
                className="px-4 py-3 font-medium outline-none"
                style={{ borderRadius: 4, border: "none", color: DARK, fontSize: "0.9rem" }}
              />
              <textarea
                placeholder="Your message…"
                rows={3}
                required
                className="px-4 py-3 font-medium outline-none resize-none"
                style={{ borderRadius: 4, border: "none", color: DARK, fontSize: "0.9rem" }}
              />
              <div>
                <button
                  type="submit"
                  className="font-bold tracking-widest uppercase px-7 py-3 transition-all hover:-translate-y-0.5 hover:shadow-md"
                  style={{ background: GOLDEN, color: DARK, borderRadius: 4, fontSize: "0.88rem", fontWeight: 900 }}
                >
                  Send Message
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

// ── MAIN PAGE ─────────────────────────────────────────────────────────────────
export default function Home() {
  const [activeTab, setActiveTab] = useState("about");
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => {
    const ids = ["about", "fiction", "nonfiction", "speaker", "workshops"];
    const obs = new IntersectionObserver(
      entries => {
        entries.forEach(e => { if (e.isIntersecting) setActiveTab(e.target.id); });
      },
      { rootMargin: "-40% 0px -55% 0px" }
    );
    ids.forEach(id => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  function scrollTo(id: string) {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
    setActiveTab(id);
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: CREAM }}>

      {/* ── STICKY NAV ── */}
      <nav
        className={`sticky top-0 z-50 transition-shadow ${scrolled ? "shadow-md" : ""}`}
        style={{ background: "#fdf5ea", borderBottom: `1px solid #d4c4a8` }}
      >
        <div className="container">
          {/* Site title */}
          <div className="text-center py-3 border-b" style={{ borderColor: "#d4c4a8" }}>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              style={{
                fontFamily: "'Dancing Script', cursive",
                color: DARK,
                fontSize: "clamp(1.5rem, 4vw, 2.2rem)",
                background: "none",
                border: "none",
              }}
            >
              Dr. Heather Allansdottir
            </button>
            <p className="font-black tracking-widest uppercase" style={{ fontSize: "0.75rem", fontWeight: 900, color: "#1a1a1a", letterSpacing: "0.15em" }}>
              Writer &bull; Academic &bull; Speaker
            </p>
          </div>
          {/* Tab row */}
          <div className="flex justify-center flex-wrap">
            {TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => scrollTo(tab.id)}
                className="font-black tracking-widest uppercase px-4 md:px-5 py-3 border-b-2 transition-all whitespace-nowrap"
                style={{
                  background: "transparent",
                  fontSize: "0.75rem",
                  fontWeight: 900,
                  letterSpacing: "0.12em",
                  color: activeTab === tab.id ? CORAL : "#1a1a1a",
                  borderBottomColor: activeTab === tab.id ? CORAL : "transparent",
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* ── SECTIONS ── */}
      <main className="flex-1">
        <HeroSection />
        <AboutSection />
        <FictionSection />
        <NonFictionSection />
        <MailingListSection />
        <SpeakerSection />
        <WorkshopsSection />
        <ContactSection />
      </main>

      {/* ── FOOTER ── */}
      <div className="w-full overflow-hidden" style={{ height: 64 }}>
        <img src={FLORAL_BORDER} alt="" aria-hidden className="w-full h-full object-cover" />
      </div>
      <footer
        className="text-center py-5 font-semibold tracking-wide"
        style={{ background: CORAL, color: "rgba(255,255,255,0.9)", fontSize: "0.82rem" }}
      >
        &copy; {new Date().getFullYear()} Dr. Heather Allansdottir &nbsp;&mdash;&nbsp;
        <a
          href="https://allofallansdottir.substack.com"
          target="_blank"
          rel="noopener noreferrer"
          className="font-bold hover:text-white transition-colors underline"
        >
          Substack
        </a>
      </footer>
    </div>
  );
}
